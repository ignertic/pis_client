import logging
import requests
import os



class Bluedot(object):
    """docstring for Bluedot."""
    def __init__(self, arg):
        super(Bluedot, self).__init__()
        self.arg = arg
        
