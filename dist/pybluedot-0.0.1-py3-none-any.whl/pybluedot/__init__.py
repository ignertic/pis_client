from bluedot import Bluedot

name = "bluedot"
