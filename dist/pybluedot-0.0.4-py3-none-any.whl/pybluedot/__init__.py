import model
name = "bluedot"
data = '{"ErrorCode":"000","ErrorMessage":"Done","JobId":"20047","MessageData":[{"Number":"91989xxxxxxx","MessageId":"mvHdpSyS7UOs9hjxixQLvw"},{"Number":"917405080952","MessageId":"PfivClgH20iG6G5R3usHwA"}]}'





class Bluedot(model.DataParse):
    """Bluedot.


     -params
        *Username & Password
        *Profile load file

    //Tasks:
        -Obtain credentials
        -Check if valid by checking balance
        -Log successful login
        -Send msgs



    """

    balance = None
    content = None
    error = None

    def __init__(self, **kwargs):
        super(Bluedot, self).__init__()
        self.kwargs = kwargs
        self.password = kwargs.get("password")
        self.username = kwargs.get("username")
        print(self._extract_sms_data)
        # self.sender_name = if kwargs.get("sender_name") else "Bluedot"


    @staticmethod
    def __clean_number(contact):
        #remove symbols
        return contact.replace("+", "").strip()
    def send_sms(self,msg,contacts):
        if type(contacts) is str:
            #Check number validity (NoB)
            contact = self.__clean_number(contacts)
    def test(self):
        # print self.__get_status_codes(data)
        pass


    def __dir__(self):
        return [i for i in dir(self) if i[0] is not '_']
    def __repr__(self):
        return "SuperCode"
    def __call__(self):
        return self.username

    def __len__(self):
        return len(self.username)

    def __getitem__(self, item):
        return self.test[item]

    def __str__(self):
        if self.username is None:
            return self.__class__.__name__
